/*
 This file will generate the .txt file needed for Chi Square
 Outputs data with 4 columns: r, v_lum, v_dm, h

 Created by: David Chester
 Date:6/19/2012
 */


#include <deque>
#include <string>

class Galaxy;

class CalcH{

    public:
        CalcH();
        CalcH(const Galaxy *milky_galaxy, const Galaxy *_other_galaxy);
        ~CalcH();

        void setGalaxies(const Galaxy *milky_galaxy, const Galaxy *other_galaxy);

        void readData(const std::string& data_filename, const std::string& dataerror_filename);

        void makeFile(const std::string& file);

        const std::deque<double>& getR();

        const std::deque<double>& getvLum();

        const std::deque<double>& getvData();

    private:
        void calcGalaxyInfo(const Galaxy *milky, const Galaxy *other);

        void trimVectors();

        std::deque< std::deque<double> > readfile (const std::string& filename);

        // Galaxy model information
        struct GalaxyInfo
	{
	    std::deque< double > r, vlum, /*F, ang, phi, J, b, gtp, gtt, gpp,*/ n/*, romega, deltac, mass*/;
	} milky, other;

        // Actual rotation curve of the galaxy in question
        struct DataInfo
	{
	    std::deque< double > r, v, vError;
	} data;

        // Tolerance for equating radial positions
        double rTolerance;
};
