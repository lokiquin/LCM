/*
 This file will generate the .txt file needed for Chi Square
 Outputs data with 4 columns: r, v_lum, v_dm, h

 Created by: David Chester
 Date:6/19/2012
 */


#include <string>
#include <deque>

class Galaxy{

    public:
        Galaxy();
        ~Galaxy();

        void readBulge(const std::string& bulgefile);

        void readGas(const std::string& gasfile);

        void readDisc(const std::string& discfile);

        void readLum(const std::string& lumfile);

        void setConstant(double newConstant);

        void calcLum();

        void calcPhiB();

        void calcDeltaC();

        void calcError();

        void printError();

        const std::deque<double>& getMass() const;

        const std::deque< std::deque<double> >& getBulge() const;

        const std::deque< std::deque<double> >& getDisc() const;

        const std::deque<double>& getLum() const;

        const  std::deque<double>& getR() const;

        const std::deque<double>& getForce() const;

        const std::deque<double>& getPhi() const;

        const std::deque<double>& getAngMom() const;

        const std::deque<double>& getJ() const;

        const std::deque<double>& getB() const;

        const std::deque<double>& getGtp() const;

        const std::deque<double>& getGtt() const;

        const std::deque<double>& getGpp() const;

        const std::deque<double>& getN() const;

    //const std::deque<double>& getROmega() const;

    //const std::deque<double>& getDeltaC() const;

        void Print(const std::deque< std::deque<double> >& data) const;

        void Print(const std::deque<double>& data) const;

        void printBulge() const;
        void printDisc() const;
        void printLum() const;
        void printR() const;
        void printRBulge() const;
        void printRDisc() const;
        void printForce() const;
        void printPhi() const;
        void printAngMom() const;
        void printJ() const;
        void printB() const;
        void printGtp() const;
        void printGtt() const;
        void printGpp() const;
        void printN() const;
    //void printROmega() const;
    //void printDeltaC() const;
        void printMass() const;

    private:
        std::deque< std::deque<double> > readfile (const std::string& filename) const;

        std::deque<double> integrate(const std::deque<double>& data) const;

        // Used to read files
        std::deque< std::deque<double> > bulge, disc, gas, dm;
        // Used in calculations
        double constant;
        std::deque<double> r, vlum, force, phi, angmom, J, b, gtp, gtt, gpp, n, /*romega, deltac,*/ mass;
        // Error, used in calcError()
        std::deque<double> dr, dvlum, dforce, dphi, dangmom, dJ, db, dgtp, dgtt, dgpp, dn/*, dromega, ddeltac*/;
        bool bulgeExist, discExist, gasExist, lumExist;

};
