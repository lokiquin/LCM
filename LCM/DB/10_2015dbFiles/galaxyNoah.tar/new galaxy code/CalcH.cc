/*
 This file will generate the .txt file needed for Chi Square
 Outputs data with 4 columns: r, v_lum, v_dm, h

 Created by: David Chester
 Date:6/19/2012
 */

#include "CalcH.hh"
#include "Galaxy.hh"
#include "Constants.hh"

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <sstream>

using namespace std;

CalcH::CalcH() :
    milky(),
    other(),
    data()
    //h()
{}

CalcH::CalcH(const Galaxy *milky_galaxy, const Galaxy *other_galaxy) :
    milky(),
    other(),
    data(),
    rTolerance(1.)
{
    calcGalaxyInfo(milky_galaxy, other_galaxy);
}
CalcH::~CalcH()
{}

void CalcH::setGalaxies(const Galaxy *milky_galaxy, const Galaxy *other_galaxy)
{
    calcGalaxyInfo(milky_galaxy, other_galaxy);
    return;
}

void CalcH::calcGalaxyInfo(const Galaxy *milky_galaxy, const Galaxy *other_galaxy)
{
    const deque<double>& rm = milky_galaxy->getR();
    const deque<double>& ro = other_galaxy->getR();
    int lenm = rm.size();
    int leno = ro.size();

    deque<int> im(lenm), io(leno); //Indices for matching milky and other data
    // Should find one milky r value per every other galaxy r value
    for (int j=0; j<leno; j++)
    {
        double diffstore = 1000.0;
        io[j] = j+1; // labels other r values 1 thru leno
        int imtemp=0;
        for (int i=0; i<lenm; i++)
        {
            //im[i] = 0.0; //Initialize to 0.
            double diff = fabs(rm[i]-ro[j]);
            if (diff < diffstore){
                //cout << "i = "<<i<<", j = "<<j<<", rm = "<<rm[i]<<", ro = "<<ro[j]<< endl;
                imtemp = i; //stores the index that matches with j
                diffstore = diff;
            }
        }
        im[imtemp] = j+1;
    }

    /*
    for (int j=0; j<leno; j++){
        cout << "io["<<j<<"] = " << io[j] << endl;
    }

    for (int j=0; j<lenm; j++){
        cout << "im["<<j<<"] = " << im[j] << endl;
    }
    */

    for (int j=0; j<leno; j++)
    {
        int count = 0;
        for (int i=0; i<lenm; i++)
        {
            if (im[i] == j+1)
            {
                count++;
                //cout << im[i]<<", " << j+1<< endl;
            }
            if (im[i] == io[j])
            {
                //cout <<"index = "<<im[i]<<", r_m = " << rm[i]<<", r_o = " << ro[j] << endl;
            }
        }
        //cout <<"count = " << count << endl;
        if (count == 0)
        {
            cout << "Error: not enough discretization in Milky Way data. Missing #" << j+1<< endl;
        }
    }
    // io is numbered 1 thru leno
    // im has the index number which matches with io, all others values are 0

    // Upload other galaxy data, does not need to changed
    //vector<double> vlumo, Fo, ango, phio, Jo, bo, gtpo, gtto, gppo, no, romegao,deltaco;
    other.r = ro;
    other.vlum = other_galaxy->getLum();
    //other.F = other_galaxy->getForce();
    //other.ang = other_galaxy->getAngMom();
    //other.phi = other_galaxy->getPhi();
    //other.J = other_galaxy->getJ();
    //other.b = other_galaxy->getB();
    //other.gtp = other_galaxy->getGtp();
    //other.gtt = other_galaxy->getGtt();
    //other.gpp = other_galaxy->getGpp();
    other.n = other_galaxy->getN();
    //other.romega = other_galaxy->getROmega();
    //other.deltac = other_galaxy->getDeltaC();
    //other.mass = other_galaxy->getMass();
    //cout << "metric other " << other.F << endl;

    // Upload milky galaxy data, must remove data to match other galaxy
    // rm defined above
    const deque< double >& vlumm = milky_galaxy->getLum();
    //const vector< double >& Fm = milky_galaxy->getForce();
    //const vector< double >& angm = milky_galaxy->getAngMom();
    //const vector< double >& phim = milky_galaxy->getPhi();
    //const vector< double >& Jm = milky_galaxy->getJ();
    //const vector< double >& bm = milky_galaxy->getB();
    //const vector< double >& gtpm = milky_galaxy->getGtp();
    //const vector< double >& gttm = milky_galaxy->getGtt();
    //const vector< double >& gppm = milky_galaxy->getGpp();
    const deque< double >& nm = milky_galaxy->getN();
    //const vector< double >& romegam = milky_galaxy->getROmega();
    //const vector< double >& deltacm = milky_galaxy->getDeltaC();
    //const vector< double >& massm = milky_galaxy->getMass();


    cout << "num Agree for calculating h = " << leno << endl;
    // Next, remove extra data from milky way and put into new vectors.
    milky.r.resize(leno);
    milky.vlum.resize(leno);
    //milky.ang.resize(leno);
    //milky.phi.resize(leno);
    //milky.J.resize(leno);
    //milky.b.resize(leno);
    //milky.gtp.resize(leno);
    //milky.gtt.resize(leno);
    //milky.gpp.resize(leno);
    milky.n.resize(leno);
    // milky.romega.resize(leno);
    //milky.deltac.resize(leno);
    //milky.mass.resize(leno);

    //h.resize(leno);

    for (int i=0; i<lenm; i++)
    {
        for (int j=0; j<leno; j++)
        {
            if (im[i]==io[j])
            {
                milky.r[j] = rm[i];
                milky.vlum[j] = vlumm[i];
                //milky.F[j] = Fm[i];
                //.ang[j] = angm[i];
                //milky.phi[j] = phim[i];
                //milky.J[j] = Jm[i];
                //milky.b[j] = bm[i];
                //milky.gtp[j] = gtpm[i];
                //milky.gtt[j] = gttm[i];
                //milky.gpp [j] = gppm[i];
                milky.n[j] = nm[i];
                //milky.romega[j] = romegam[i];
                //milky.deltac[j] = deltacm[i];
                //milky.mass[j] = massm[i];

                //h[j] = milky.deltac[j] + other.deltac[j];
            }
        }
    }

    cout << "Successfully calculated h" << endl << endl;
}

deque< deque<double> > CalcH::readfile (const string& filename) 
{
    ifstream indata; //ifstream reads, ofstream writes, fstream does both.
    indata.open(filename.c_str());
    if(!indata)
    {
        cerr << "Error: file could not be opened: " << filename << endl;
        exit(1);
    }
    cout << "Opened " << filename << endl;

    deque<double> x, y;
    double xtemp, ytemp;
    int count = 0;

    string line;
    getline(indata,line);
    if (isdigit(line[0]))
    {
        cout << "Didn't remove 1st line." << endl;
	stringstream linestream;
	linestream << line;
	linestream >> xtemp;
	linestream >> ytemp;
	x.push_back(xtemp);
	y.push_back(ytemp);
        count++;
    }

    while (! indata.eof())
    {
        indata >> xtemp;
        indata >> ytemp;
	x.push_back(xtemp);
	y.push_back(ytemp);
        count++;
    }

    /*
    for (int i=0; i<num; i++){
        cout << "x = " << x[i] << ", y = " << y[i] << endl;
    }
    */

    indata.close();

    deque< deque<double> > answer(2);
    answer[0] = x;
    answer[1] = y;
    return answer;
}

void CalcH::readData(const string& data_filename, const string& dataerror_filename)
{
    // Read the Data file
    deque< deque<double> > Data = readfile(data_filename);

    data.r = Data[0];
    data.v = Data[1];
    cout << "Successfully uploaded DM data" << endl << endl;

    // Read the DMError file
    // Assumes error is upper error bar, so err must be subtracted
    deque< deque<double> > DataError = readfile(dataerror_filename);

    if (data.r.size() != DataError[0].size())
    {
        cout << "Error: Data Error file is different length than Data" << endl;
	exit(-1);
    }

    data.vError.resize(DataError[1].size()); // Make v_dmError the right length.
    for (int i = 0; i<data.r.size(); i++)
    {
        data.vError[i] = DataError[1][i] - data.v[i];
    }
    cout << "Successfully uploaded Data Error data." << endl << endl;
}

void CalcH::trimVectors()
{
    // Make the fronts of the vectors line up in r
    if (milky.r[0] - data.r[0] > rTolerance)
    {
	// data starts before milky
	int i;
	for (i = 1; i < data.r.size(); i++)
	{
	    if (fabs(milky.r[0] - data.r[i]) < rTolerance) break;
	}
	if (i == data.r.size())
	{
	    cerr << "Error: no overlap between data and galaxy models (data.r < milky.r)" << endl;
	    exit(-1);
	}
	// trim off the front of data
	for (int j = 0; j < i; j++)
	{
	    data.r.pop_front();
	    data.v.pop_front();
	    data.vError.pop_front();
	}
    }
    else if (data.r[0] - milky.r[0] > rTolerance)
    {
	// milky starts before data
	int i;
	for (i = 1; i < milky.r.size(); i++)
	{
	    if (fabs(data.r[0] - milky.r[i]) < rTolerance) break;
	}
	if (i == milky.r.size())
	{
	    cerr << "Error: no overlap between data and galaxy models (milky.r < data.r)" << endl;
	    exit(-1);
	}
	// trim off the front of milky and other
	for (int j = 0; j < i; j++)
	{
	    milky.r.pop_front();
	    other.r.pop_front();
	    milky.vlum.pop_front();
	    other.vlum.pop_front();
	    milky.n.pop_front();
	    other.n.pop_front();
	}
    }

    // Make the backs of the vectors line up in r
    if (data.r.size() > milky.r.size())
    {
	// data is longer than milky
	for (int i = 0; i < data.r.size() - milky.r.size(); i++)
	{
	    data.r.pop_back();
	    data.v.pop_back();
	    data.vError.pop_back();
	}
    }
    else if (milky.r.size() > data.r.size())
    {
	// milky is longer than data
	for (int i = 0; i < milky.r.size() - data.r.size(); i++)
	{
	    milky.r.pop_back();
	    other.r.pop_back();
	    milky.vlum.pop_back();
	    other.vlum.pop_back();
	    milky.n.pop_back();
	    other.n.pop_back();
	}
    }

    cout << "Number of data points for Chi Square: " << milky.r.size() << endl;
    cout << "Successfully calculated everything needed for Chi Square" << endl << endl;
}

void CalcH::makeFile(const string& file)
{
    const double c = Constants::c;
    const double overc = 1. / c;

    trimVectors();

    if (milky.r.size() != data.r.size())
    {
	cerr << "Error: for some reason the galaxy vector size is not equal to the data vector size: " << endl;
	cerr << "       milky.r.size = " << milky.r.size() << ";  milky.r[0] = " << milky.r[0] << endl;
	cerr << "       data.r.size = " << data.r.size() << ";  data.r[0] = " << data.r[0] << endl;
	exit(-1);
    }

    ofstream outdata;
    outdata.open(file.c_str());
    //outdata << "ro \t vlum \t vdm \t deltac_m \t deltac_o" << endl;
    //outdata << "rm \t ro \t vlum \t vdm \t h \t Jm \t Jo \t bm \t bo \t phim \t phio \t gtpm \t gttm \t gppm" << endl;
    //outdata << "rm \t ro \t vlum \t vdm \t nm \t no \t rOmegam \t rOmegao \t deltaCm \t detlaCo \t gtpo \t gtto \t gppo" << endl;
    for (int i=0; i<data.r.size(); i++)
    {
        //vector<double>      lamL, lamRat,CurvRat;vlum_m[i]
        // lamL_[j]=(sqrt((1+vlum_o[j]/300000.0)/(1-vlum_o[j]/300000.0)))
        // lamRat_[j] =((1-deltac_m[j]/300000.0)/(1-deltac_o[j]/300000.0))
        // CurvRat_[j]=deltac_o[j]/deltac_m[j]
        //GalRat_[j}=(n_o[j]/n_m[j])
        // Always use i for v_dm or v_dmError and j for everything else.
        //outdata <<r_m[j]<<"\t"<<r_o[j]<<"\t"<<vlum_o[j]<<"\t"<<v_dm[i]<<"\t"<<h[j]<<"\t"<<J_m[j]<<"\t"<<J_o[j]<<"\t"<<b_m[j]<<"\t"<<b_o[j]<<"\t"<<phi_m[j]<<"\t"<<phi_o[j]<<"\t"<<gtp_m[j]<<"\t"<<gtt_m[j]<<"\t"<<gpp_m[j]<<endl;
        //outdata <<r_m[j]<<"\t"<<r_o[j]<<"\t"<<vlum_o[j]<<"\t"<<v_dm[i]<<"\t"<<n_m[j]<<"\t"<<n_o[j]<<"\t"<<romega_m[j]<<"\t"<<romega_o[j]<<"\t"<<deltac_m[j]<<"\t"<<deltac_o[j]<<"\t"<<gtp_o[j]<<"\t"<<gtt_o[j]<<"\t"<<gpp_o[j]<<endl;
        //outdata <<r_o[j]<<"\t"<<vlum_o[j]<<"\t"<<v_dm[i]<<"\t"<<deltac_o[j]<<"\t"<<deltac_m[j]<<endl;
        //SYMBOLS <<r_o[j]<<"\t"<<vlum_o[j]<<"\t"<<v_dm[i]<<"\t"<<300000*(CurvRat_[j])*(lamL_[j]+lamRat_[j])/(lamL_[j]-lamRat_[j])*(lamRat_[j]-1/lamRat_[j])/(lamRat_[j]+1/lamRat_[j])<<"\t"<<v_dmError[i]<<endl;
        //Joes' columns
        //outdata <<r_o[j]<<"\t"<<vlum_o[j]<<"\t"<<v_dm[i]<<"\t"<<(deltac_o[j])<<"\t"<<(deltac_m[j])<<"\t"<<(((sqrt((1+vlum_o[j]/300000.0)/(1-vlum_o[j]/300000.0))+((1-deltac_o[j]/300000.0)/(1-deltac_m[j]/300000.0))))/(sqrt((1+vlum_o[j]/300000.0)/(1-vlum_o[j]/300000.0))-((1-deltac_o[j]/300000.0)/(1-deltac_m[j]/300000.0))))<<"\t"<<(((1-deltac_m[j]/300000.0)/(1-deltac_o[j]/300000.0))-((1-deltac_o[j]/300000.0)/(1-deltac_m[j]/300000.0)))/(((((1-deltac_m[j]/300000.0)/(1-deltac_o[j]/300000.0))+((1-deltac_o[j]/300000.0)/(1-deltac_m[j]/300000.0)))))<<endl;
        //FUNC
        outdata <<other.r[i]<<"\t"<<other.vlum[i]<<"\t"<<data.v[i]<<"\t"<<c*((1.-1./other.n[i])/(1.-1./milky.n[i]))*((sqrt((1.+other.vlum[i]*overc)/(1.-other.vlum[i]*overc)))+(other.n[i]/milky.n[i]))/((sqrt((1.+other.vlum[i]*overc)/(1.-other.vlum[i]*overc)))-(other.n[i]/milky.n[i]))*((other.n[i]/milky.n[i]) - 1./(other.n[i]/milky.n[i]))/((other.n[i]/milky.n[i]) + 1./(other.n[i]/milky.n[i]))<<"\t"<<data.vError[i]<<endl;
        //outdata <<r_o[j]<<"\t"<<vlum_o[j]<<"\t"<<v_dm[i]<<"\t"<<300000*((1-1/n_o[j])/(1-1/n_m[j]))*((sqrt((1+vlum_o[j]/300000.0)/(1-vlum_o[j]/300000.0)))+(n_o[j]/n_m[j]))/((sqrt((1+vlum_o[j]/300000.0)/(1-vlum_o[j]/300000.0)))-(n_o[j]/n_m[j]))*((n_o[j]/n_m[j]) - 1/(n_o[j]/n_m[j]))/((n_o[j]/n_m[j]) + 1/(n_o[j]/n_m[j]))<<"\t"<<v_dmError[i]<<endl;
        //Func Noah TEST
        //outdata <<r_o[j]<<"\t"<<vlum_o[j]<<"\t"<<v_dm[i]<<"\t"<<((1-1/n_o[j])/(1-1/n_m[j]))*((((1+vlum_o[j]/300000.0)/(1-vlum_o[j]/300000.0)))+(1/n_o[j])*(1/n_o[j]))/((((1+vlum_o[j]/300000.0)/(1-vlum_o[j]/300000.0)))-(1/n_o[j])*(1/n_o[j]))*((((1+vlum_o[j]/300000.0)/(1-vlum_o[j]/300000.0)))+(1/n_m[j])*(1/n_m[j]))/((((1+vlum_o[j]/300000.0)/(1-vlum_o[j]/300000.0)))-(1/n_m[j])*(1/n_m[j]))*((n_o[j]/n_m[j]) - 1/(n_o[j]/n_m[j]))/((n_o[j]/n_m[j]) + 1/(n_o[j]/n_m[j]))<<"\t"<<v_dmError[i]<<endl;
        //\\Example1
        //outdata <<r_o[j]<<"\t"<<vlum_o[j]<<"\t"<<v_dm[i]<<"\t"<<300000*((n_o[j]/n_m[j]) - 1/(n_o[j]/n_m[j]))/((n_o[j]/n_m[j]) + 1/(n_o[j]/n_m[j]))<<"\t"<<v_dmError[i]<<endl;
        //\\Example2
        //outdata <<r_o[j]<<"\t"<<vlum_o[j]<<"\t"<<v_dm[i]<<"\t"<<300000*((sqrt((1+vlum_o[j]/300000.0)/(1-vlum_o[j]/300000.0)))+(n_o[j]/n_m[j]))/((sqrt((1+vlum_o[j]/300000.0)/(1-vlum_o[j]/300000.0)))-(n_o[j]/n_m[j]))*((n_o[j]/n_m[j]) - 1/(n_o[j]/n_m[j]))/((n_o[j]/n_m[j]) + 1/(n_o[j]/n_m[j]))<<"\t"<<v_dmError[i]<<endl;
        //\\Example3
        //outdata <<r_o[j]<<"\t"<<vlum_o[j]<<"\t"<<v_dm[i]<<"\t"<<300000*((1-1/n_o[j])/(1-1/n_m[j]))*((sqrt((1+vlum_o[j]/300000.0)/(1-vlum_o[j]/300000.0)))+(n_o[j]/n_m[j]))/((sqrt((1+vlum_o[j]/300000.0)/(1-vlum_o[j]/300000.0)))-(n_o[j]/n_m[j]))*((n_o[j]/n_m[j]) - 1/(n_o[j]/n_m[j]))/((n_o[j]/n_m[j]) + 1/(n_o[j]/n_m[j]))<<"\t"<<v_dmError[i]<<endl;
        //t1  t2   t3
        //outdata <<r_o[j]<<"\t"<<((1-1/n_o[j])/(1-1/n_m[j]))<<"\t"<<((sqrt((1+vlum_o[j]/300000.0)/(1-vlum_o[j]/300000.0)))+(n_o[j]/n_m[j]))/((sqrt((1+vlum_o[j]/300000.0)/(1-vlum_o[j]/300000.0)))-(n_o[j]/n_m[j]))<<"\t"<<((n_o[j]/n_m[j]) - 1/(n_o[j]/n_m[j]))/((n_o[j]/n_m[j]) + 1/(n_o[j]/n_m[j]))<<endl;
    }
    outdata.close();
    cout << "Successfully created file for Chi Square: " << file << endl;
}

const deque<double>& CalcH::getR()
{
    return milky.r;
}

const deque<double>& CalcH::getvLum()
{
    return other.vlum;
}

const deque<double> & CalcH::getvData()
{
    return data.v;
}

