/*
 This file will generate the .txt file needed for Chi Square
 Outputs data with 4 columns: r, v_lum, v_dm, h

 Created by: David Chester
 Date:6/19/2012
 */

#include "Galaxy.hh"
#include "Constants.hh"

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <sstream>


using namespace std;

Galaxy::Galaxy() :
    bulge(), disc(), gas(),
    constant(1.0),
    r(), vlum(), force(), phi(), angmom(), J(), b(), gtp(), gtt(), gpp(), n(), mass(),
    dr(), dvlum(), dforce(), dphi(), dangmom(), dJ(), db(), dgtp(), dgtt(), dgpp(), dn(),
    bulgeExist(false), discExist(false), gasExist(false), lumExist(false)
{
}

Galaxy::~Galaxy()
{}

deque< deque<double> > Galaxy::readfile (const string& filename) const
{
    ifstream indata; //ifstream reads, ofstream writes, fstream does both.
    indata.open(filename.c_str());
    if(!indata){
        cerr << "Error: file could not be opened: " << filename << endl;
        exit(1);
    }
    cout << "Opened " << filename << endl;

    deque<double> x, y;
    double xtemp, ytemp;
    int count = 0;

    string line;
    getline(indata,line);
    if (isdigit(line[0]))
    {
        cout << "Didn't remove 1st line." << endl;
	stringstream linestream;
	linestream << line;
	linestream >> xtemp;
	linestream >> ytemp;
	x.push_back(xtemp);
	y.push_back(ytemp);
        count++;
    }

    while (! indata.eof())
    {
        indata >> xtemp;
        indata >> ytemp;
	x.push_back(xtemp);
	y.push_back(ytemp);
        count++;
    }

    /*
    for (int i=0; i<num; i++){
        cout << "x = " << x[i] << ", y = " << y[i] << endl;
    }
    */

    indata.close();

    deque< deque<double> > answer(2);
    answer[0] = x;
    answer[1] = y;
    return answer;
}

void Galaxy::readBulge(const string& bulgefile)
{
    bulge = readfile(bulgefile);
    bulgeExist = true;
    cout << "Successfully uploaded bulge data." << endl << endl;
}

void Galaxy::readGas(const string& gasfile)
{
    gas = readfile(gasfile);
    gasExist = true;
    cout << "Successfully uploaded bulge data." << endl << endl;
}

void Galaxy::readDisc(const string& discfile)
{
    disc = readfile(discfile);
    discExist = true;
    cout << "Successfully uploaded disc data." << endl << endl;
}

void Galaxy::readLum(const string& lumfile)
{
    deque< deque<double> > answer = readfile(lumfile);
    r = answer[0];
    vlum = answer[1];

    for (int i = 0; i<vlum.size(); i++){
        vlum[i] = constant*vlum[i];
    }

    lumExist = true;
    cout << "Successfully uploaded lum data." << endl << endl;
}

void Galaxy::setConstant(double newConstant)
{
    constant = newConstant;
}

void Galaxy::calcLum()
{
    if (lumExist) return;

    if (! bulgeExist && ! discExist && ! gasExist)
    {
         cerr << "Error in calcLum(): There are no velocity contributions loaded." << endl;
	 exit(-1);
    }


    //find out how many agree in r
    if (bulge.size() == disc.size())
    {
        //If rbulge and rdisc line up and roughly agree
	int lumSize = bulge.size();
        r.resize(lumSize);
	vlum.resize(lumSize); // to be evaluated at rlum

	const deque< double >& rgas = gas[0];
	const deque< double >& rdisc = disc[0];
	const deque< double >& rbulge = bulge[0];

        double vlumBulge; // evaluated at rlum
        double vlumDisc; // evaluated at rlum
        double vlumGas; // evaluated at rlum

	// Add the radii, and add the lum components in quadrature
        for (int i=0; i<lumSize; i++){
	    int count = 0;
	    double rSum = 0.;
	    double vlumSum = 0.;
	    if (gasExist)
	    {
	        count++;
	        rSum += rgas[i];
	        vlumSum += gas[1][i] * gas[1][i];
	    }
	    if (discExist)
	    {
		count++;
		rSum += rdisc[i];
		vlumSum += disc[1][i] * disc[1][i];
	    }
	    if (bulgeExist)
	    {
		count++;
		rSum += rbulge[i];
		vlumSum += bulge[1][i] * bulge[1][i];
	    }
	    if (count < 1)
	    {
		cerr << "No components were present for the calculation !" << endl;
		exit(0);
	    }
	    r[i] = rSum / (double)count;
	    //rErr[i] = ...

	    vlum[i] = constant * sqrt(vlumSum);

        }
    }
    else 
    {
	cerr << "Error: disc length and bulge length are not equal." << endl;
	exit(-1);
    }

    cout << "Successfully calculated v_lum in quadrature" << endl << endl;
}

void Galaxy::calcPhiB()
{
    const double oneOverG = 1. / Constants::G;
    // Calculate enclosed mass M(r) = v^2*r/G
    mass.resize(vlum.size());
    mass[0] = vlum[0]*vlum[0]*r[0]*oneOverG;
    for (int i=1; i<vlum.size(); i++)
    {
        mass[i] = vlum[i]*vlum[i]*r[i]*oneOverG;
    }

    //find force: F=2*lum^2/(r*c^2) and angmom: 3*lum^3*r
    const double c = Constants::c;
    force.resize(vlum.size());
    angmom.resize(vlum.size());
    for (int i=0; i<vlum.size(); i++)
    {
        force[i] = 2.0*vlum[i]*vlum[i]/(r[i]*c*c);//checked.
        angmom[i] = 3.0*vlum[i]*vlum[i]*vlum[i]*r[i];
    }
    //integrate force to get phi
    phi = integrate(force);
    //integrate angmom (J_n) to get J(r)
    J = integrate(angmom);
    //calculate b from J
    b.resize(vlum.size());
    for (int i=0; i<vlum.size(); i++){
        b[i] = J[i]/(r[i]*r[i]*c*vlum[i]*vlum[i]);
    }
    cout << "Successfully calculated phi and b" << endl << endl;
}

deque<double> Galaxy::integrate(const deque<double>& data) const
{
    int len = data.size();
    deque<double> integral(len);
    integral[0] = r[0]*data[0]/2.0;
    for (int i=1; i<len; i++){
        double integ = integral[i-1];
        integral[i] = (data[i]+data[i-1])*(r[i]-r[i-1])/2.0 + integ;
    }
    return integral;
}

void Galaxy::calcDeltaC()
{
    const double c = Constants::c;
    int size = vlum.size();
    gtt.resize(size);
    gtp.resize(size);
    gpp.resize(size);
    n.resize(size);
    //deque<double> Romega(lum.size());
    //deque<double> Deltac(lum.size());
    for(int i=0; i<size; i++){
        gtp[i] = -1.0*r[i]*phi[i]*b[i];
        gtt[i] = -1.0*(1.0-phi[i]);
        gpp[i] = r[i]*r[i]*(1.0+b[i]*b[i]*(1.0+phi[i]));
        //N[i]=(Gtp[i]+sqrt(Gtp[i]*Gtp[i]-Gtt[i]*Gpp[i]))/(-1.0*Gtt[i]*sqrt(Gpp[i]));
        n[i]=(-1.0*r[i]*phi[i]*b[i]+sqrt(r[i]*phi[i]*b[i]*r[i]*phi[i]*b[i]+(1.0-phi[i])*r[i]*r[i]*(1.0+b[i]*b[i]*(1.0+phi[i]))))/((1.0-phi[i])*sqrt(r[i]*r[i]*(1.0+b[i]*b[i]*(1.0+phi[i]))));
        //Romega[i] = 1.0/(N[i]*sqrt(1.0+b[i]*b[i]*(1.0+phi[i])));
        //Romega[i] = 1.0/((-1.0*r[i]*phi[i]*b[i]+sqrt(r[i]*phi[i]*b[i]*r[i]*phi[i]*b[i]+(1.0-phi[i])*r[i]*r[i]*(1.0+b[i]*b[i]*(1.0+phi[i]))))/((1.0-phi[i])*sqrt(r[i]*r[i]*(1.0+b[i]*b[i]*(1.0+phi[i]))))*sqrt(1.0+b[i]*b[i]*(1.0+phi[i])));
        //Deltac[i] = c*(1.0-Romega[i]);
        //Deltac[i] = c*(1.0-1.0/((-1.0*r[i]*phi[i]*b[i]+sqrt(r[i]*phi[i]*b[i]*r[i]*phi[i]*b[i]+(1.0-phi[i])*r[i]*r[i]*(1.0+b[i]*b[i]*(1.0+phi[i]))))/((1.0-phi[i])*sqrt(r[i]*r[i]*(1.0+b[i]*b[i]*(1.0+phi[i]))))*sqrt(1.0+b[i]*b[i]*(1.0+phi[i]))));
    }
    cout << "Successfully calculated DeltaC" << endl << endl;
}

void Galaxy::calcError()
{
    const double c = Constants::c;
    if (bulge.size() == disc.size())
    {
	int size = bulge.size();
	dr.resize(size);
	dvlum.resize(size);
	dforce.resize(size);
 	dphi.resize(size);
	dangmom.resize(size);
	dJ.resize(size);
	db.resize(size);
	dgtp.resize(size);
	dgtt.resize(size);
	dgpp.resize(size);
	dn.resize(size);
        for (int i=0; i<disc.size(); i++)
        {
            dr[i] = abs(disc[0][i] - bulge[0][i])/2.0;
            if (i==0){dvlum[i] = (vlum[i+1]-vlum[i])/(r[i+1]-r[i])*dr[i];}
            else {dvlum[i] = (vlum[i]-vlum[i-1])/(r[i]-r[i-1])*dr[i];}
            dforce[i] = sqrt(pow(4.*vlum[i]*dvlum[i]/(c*c*r[i]),2)
                    + pow(4.*vlum[i]*vlum[i]*dr[i]/(c*c*r[i]*r[i]),2));
            if (i==0){dphi[i] = pow(r[i+1]*dforce[i]/2.0,2)
                + pow(force[i+1]*dr[i]/2.0,2);}
            else if (i==(disc.size()-1)){dphi[i] = dphi[i-1] + pow(r[i-1]*dforce[i]/2.0,2) + pow((force[i-1]+force[i])*dr[i]/2.0,2);}
            else {dphi[i] = dphi[i-1] + pow((r[i+1]+r[i-1])*dforce[i]/2.0,2)
                + pow((force[i-1]-force[i+1])*dr[i]/2.0,2);}
            dangmom[i] = sqrt(pow(9.0*vlum[i]*vlum[i]*r[i]*dvlum[i],2)
                    + pow(3.0*vlum[i]*vlum[i]*vlum[i]*dr[i],2));
            if (i==0){dJ[i] = pow(r[i+1]*dangmom[i]/2.0,2)
                + pow(angmom[i+1]*dr[i]/2.0,2);}
            else if (i==(disc.size()-1)){dJ[i] = dJ[i-1] + pow(r[i-1]*dangmom[i]/2.0,2) + pow((angmom[i-1]+angmom[i])*dr[i]/2.0,2);}
            else {dJ[i] = dJ[i-1] + pow((r[i+1]+r[i-1])*dangmom[i]/2.0,2)
                + pow((angmom[i-1]-angmom[i+1])*dr[i]/2.0,2);}
            db[i] = sqrt(pow(dJ[i]/(c*pow(r[i]*vlum[i],2)),2)
                    + pow(2.0*J[i]*dr[i]/(pow(r[i]*vlum[i],2)*r[i]*c),2)
                    + pow(2.0*J[i]*dvlum[i]/(pow(r[i]*vlum[i],2)*vlum[i]*c),2));
            dgtp[i] = sqrt(pow(phi[i]*b[i]*dr[i],2) + pow(r[i]*b[i]*dphi[i],2)
                    + pow(phi[i]*r[i]*db[i],2));
            dgtt[i] = dphi[i];
            dgpp[i] = sqrt(pow(2.0*r[i]*(1.0+b[i]*b[i]*(1.0+phi[i]))*dr[i],2)
                    + pow(2.0*r[i]*r[i]*b[i]*(1.0+phi[i])*db[i],2)
                    + pow(pow(r[i]*b[i],2)*dphi[i],2));
            dn[i] = sqrt(pow((1.0+gtp[i]/sqrt(gtp[i]*gtp[i]-gtt[i]*gpp[i]))*dgtp[i]/(gtt[i]*sqrt(gpp[i])),2)
                    + pow((1.0/(2.0*sqrt(gpp[i]*(gtp[i]*gtp[i]-gtt[i]*gpp[i])))+(gtp[i]+sqrt(gtp[i]*gtp[i]-gtt[i]*gpp[i]))/(2.0*gtt[i]*pow(gpp[i],1.5)))*dgpp[i],2)
                    + pow((sqrt(gpp[i]/(gtp[i]*gtp[i]-gtt[i]*gpp[i]))/(2.0*gtt[i])+(gtp[i]+sqrt(gtp[i]*gtp[i]-gtt[i]*gpp[i]))/(sqrt(gpp[i])*gtt[i]*gtt[i]))*dgtt[i],2));
            //DrO[i] = sqrt(pow(Dn[i]/(n[i]*n[i]),2)/(1.0+b[i]*b[i]*(1+phi[i]))
            //        + pow(b[i]*(1.0+phi[i])*Db[i]/n[i],2)/pow(1.0+b[i]*b[i]*(1.0+phi[i]),3)
            //        +pow(b[i]*b[i]*Dphi[i]/(2.0*n[i]),2)/pow(1.0+b[i]*b[i]*(1.0+phi[i]),3));
            //Ddc[i] = c*DrO[i];
        }
        // Still need to square root Dphi and DJ
        for (int i=0; i<disc.size(); i++)
        {
            dphi[i] = sqrt(dphi[i]);
            dJ[i] = sqrt(dJ[i]);
        }
    }
    else {
        cout << "Cannot calculate Error yet for different length disc and bulge data" << endl;
    }

}

void Galaxy::printError()
{
    for (int i=0; i<vlum.size(); i=i+10){cout << "r["<<i<<"] = " <<r[i]<<" +/- "<<dr[i]<< endl;}
    for (int i=0; i<vlum.size(); i=i+10){cout << "v["<<i<<"] = " <<vlum[i]<<" +/- "<<dvlum[i]<< endl;}
    for (int i=0; i<vlum.size(); i=i+10){cout << "F["<<i<<"] = " <<force[i]<<" +/- "<<dforce[i]<< endl;}
    for (int i=0; i<vlum.size(); i=i+10){cout << "phi["<<i<<"] = " <<phi[i]<<" +/- "<<dphi[i]<< endl;}
    for (int i=0; i<vlum.size(); i=i+10){cout << "ang["<<i<<"] = " <<angmom[i]<<" +/- "<<dangmom[i]<< endl;}
    for (int i=0; i<vlum.size(); i=i+10){cout << "J["<<i<<"] = " <<J[i]<<" +/- "<<dJ[i]<< endl;}
    for (int i=0; i<vlum.size(); i=i+10){cout << "b["<<i<<"] = " <<r[i]<<" +/- "<<db[i]<< endl;}
    for (int i=0; i<vlum.size(); i=i+10){cout << "gtp["<<i<<"] = " <<gtp[i]<<" +/- "<<dgtp[i]<< endl;}
    for (int i=0; i<vlum.size(); i=i+10){cout << "gtt["<<i<<"] = " <<gtt[i]<<" +/- "<<dgtt[i]<< endl;}
    for (int i=0; i<vlum.size(); i=i+10){cout << "gpp["<<i<<"] = " <<gpp[i]<<" +/- "<<dgpp[i]<< endl;}
    for (int i=0; i<vlum.size(); i=i+10){cout << "n["<<i<<"] = " <<n[i]<<" +/- "<<dn[i]<< endl;}
    //for (int i=0; i<vlum.size(); i=i+10){cout << "rO["<<i<<"] = " <<romega[i]<<" +/- "<<dromega[i]<< endl;}
    //for (int i=0; i<vlum.size(); i=i+10){cout << "dc["<<i<<"] = " <<deltac[i]<<" +/- "<<ddeltac[i]<< endl;}
}

const deque<double>& Galaxy::getMass() const
{
    return mass;
}

const deque< deque<double> >& Galaxy::getBulge() const
{
    return bulge;
}

const deque< deque<double> >& Galaxy::getDisc() const
{
    return disc;
}

const deque<double>& Galaxy::getLum() const
{
    return vlum;
}

const deque<double>& Galaxy::getR() const
{
    return r;
}

const deque<double>& Galaxy::getForce() const
{
    return force;
}

const deque<double>& Galaxy::getPhi() const
{
    return phi;
}

const deque<double>& Galaxy::getAngMom() const
{
    return angmom;
}

const deque<double>& Galaxy::getJ() const
{
    return J;
}

const deque<double>& Galaxy::getB() const
{
    return b;
}

const deque<double>& Galaxy::getGtp() const
{
    return gtp;
}

const deque<double>& Galaxy::getGtt() const
{
    return gtt;
}

const deque<double>& Galaxy::getGpp() const
{
    return gpp;
}

const deque<double>& Galaxy::getN() const
{
    return n;
}
/*
const deque<double>& Galaxy::getROmega() const
{
    return romega;
}

const deque<double>& Galaxy::getDeltaC() const
{
    return deltac;
}
*/
void Galaxy:: Print(const deque< deque<double> >& data) const
{
    int length = data[0].size();
    for (int i=0; i<length; i++){
        cout << data[0][i] <<" "<< data[1][i] << endl;
    }
}

void Galaxy::Print(const deque<double>& data) const
{
    int length = data.size();
    for (int i=0; i<length; i++){
        //cout << r[i]<<"\t"<< data[i] << endl;
        cout << data[i]<< endl;
    }
}

void Galaxy::printBulge() const
{cout<<"Bulge: "<< endl; Print(bulge);}
void Galaxy::printDisc() const
{cout<<"Disc: "<< endl; Print(disc);}
void Galaxy::printLum() const
{cout<<"vLum: "<< endl; Print(vlum);}
void Galaxy::printR() const
{cout<<"r: " << endl; Print(r);}
void Galaxy::printRBulge() const
{cout<<"r: " << endl; Print(bulge[0]);}
void Galaxy::printRDisc() const
{cout<<"r: " << endl; Print(disc[0]);}
void Galaxy::printForce() const
{cout<<"Force: "<< endl; Print(force);}
void Galaxy::printPhi() const
{cout<<"Phi: "<< endl; Print(phi);}
void Galaxy::printAngMom() const
{cout<<"AngMom: "<< endl; Print(angmom);}
void Galaxy::printJ() const
{cout<<"J: "<< endl; Print(J);}
void Galaxy::printB() const
{cout<<"b: "<< endl; Print(b);}
void Galaxy::printGtp() const
{cout<<"gtp: "<< endl; Print(gtp);}
void Galaxy::printGtt() const
{cout<<"gtt: "<< endl; Print(gtt);}
void Galaxy::printGpp() const
{cout<<"gpp: "<< endl; Print(gpp);}
void Galaxy::printN() const
{cout<<"n: "<< endl; Print(n);}
/*
void Galaxy::printROmega() const
{cout<<"romgea: "<< endl; Print(romega);}
void Galaxy::printDeltaC() const
{cout<<"deltac: "<< endl; Print(deltac);}
*/
void Galaxy::printMass() const
{cout<<"mass: "<< endl; Print(mass);}
