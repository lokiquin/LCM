/*
 This file will generate the .txt file needed for Chi Square
 Outputs data with 4 columns: r, v_lum, v_dm, h

 Created by: David Chester
 Date:6/19/2012
 */

#include "Galaxy.hh"
#include "GalaxyDB.hh"
#include "CalcH.hh"

#include <iostream>
#include <unistd.h>

using namespace std;


bool LoadGalaxyFiles(const string& galaxyLabel, Galaxy* galaxy, GalaxyDB* allGalaxies);


int main(int argc, char** argv){
    if (argc < 2)
    {
        cout << "Usage: ./ReadGalaxy [options]" << endl;
	cout << "Options:" << endl;
	cout << "\t-g [galaxy label] -- required -- specifies the galaxy used" << endl;
	cout << "\t-d [galaxy db file] -- optional [galaxies.db] -- specifies the galaxy DB file used" << endl;
	cout << "\t-c [constant] -- optional [1.0] - scales the luminous matter distribution" << endl;
        return 0;
    }

    string galaxyLabel("");
    string galaxyDBFilename("galaxies.db");
    double multConstant = 1.;

    int arg;
    extern char *optarg;
    while ((arg = getopt(argc, argv, "g:d:c")) != -1)
        switch (arg)
        {
            case 'g':
                galaxyLabel = string(optarg);
                break;
            case 'd':
                galaxyDBFilename = string(optarg);
                break;
            case 'c':
                multConstant = atof(optarg);
                break;
        }
    if (galaxyLabel.empty())
    {
	cerr << "Error: Please specify a galaxy using the -g flag." << endl;
	return -1;
    }


    // Load the galaxy DB
    GalaxyDB allGalaxies(galaxyDBFilename, "Label");
    if (! allGalaxies.DBIsReady())
    {
	cerr << "Error: galaxy DB was not loaded" << endl;
	return -1;
    }

    // Ensure that the Milky Way is in the DB
    string mwLabel("MilkyWay");
    if (! allGalaxies.HasGalaxy(mwLabel))
    {
	cerr << "Error: Milky Way was not in the galaxy DB" << endl;
	return -1;
    }

    // Load the other galaxy
    if (! allGalaxies.HasGalaxy(galaxyLabel))
    {
	cerr << "Error: unknown galaxy: " << galaxyLabel << endl;
	return -1;
    }

    string dataFile = allGalaxies.GetFile(galaxyLabel, "Data");
    string dataErrorFile = allGalaxies.GetFile(galaxyLabel, "DataError");
    string outFile = allGalaxies.GetFile(galaxyLabel, "Out");

    // TODO: Check to make sure dataFile, dataErrorFile, and outFile loaded

    // Load the other galaxy
    Galaxy other;
    other.setConstant(multConstant);
    if (! LoadGalaxyFiles(galaxyLabel, &other, &allGalaxies))
    {
	cerr << "Error: files did not load for galaxy <" << galaxyLabel << ">" << endl;;
        return -1;
    }

    // Load the Milky Way
    Galaxy milky;
    milky.setConstant(multConstant);
    if (! LoadGalaxyFiles(mwLabel, &milky, &allGalaxies))
    {
	cerr << "Error: files did not load for galaxy <" << mwLabel << ">" << endl;
        return -1;
    }

    // Calculations for the other galaxy
    other.calcLum();
    other.calcPhiB();
    other.calcDeltaC();
    other.printMass();


    // Calculations for the Milky Way
    //milky->readBulge("Bulge_MW_30.txt");
    //milky->readDisc("Disc_MW_30.txt");
//milky->readBulge("MW_lum_AnatolyB.txt");
//milky->readDisc("MW_lum_zeroFileB.txt");
    milky.calcLum();
    milky.calcPhiB();
    milky.calcDeltaC();
    milky.printMass();


    CalcH both(&milky, &other);

    both.readData(dataFile, dataErrorFile);
    both.makeFile(outFile);

    return 0;
}


bool LoadGalaxyFiles(const string& galaxyLabel, Galaxy* galaxy, GalaxyDB* allGalaxies)
{
    string lumFile = allGalaxies->GetFile(galaxyLabel, "Lum");
    if (! lumFile.empty())
    {
	//galaxy->readLum(lumFile);
	cout << "Read lum file: " << lumFile << endl;
	return true;
    }
    else
    {
	string bulgeFile = allGalaxies->GetFile(galaxyLabel, "Bulge");
	if (! bulgeFile.empty())
	{
	    //galaxy->readBulge(bulgeFile);
	    cout << "Read bulge file: " << bulgeFile << endl;
	}
	string discFile = allGalaxies->GetFile(galaxyLabel, "Disc");
	if (! discFile.empty()) 
	{
	    //galaxy->readDisc(discFile);
	    cout << "Read disc file: " << discFile << endl;
	}
	string gasFile = allGalaxies->GetFile(galaxyLabel, "Gas");
	if (! gasFile.empty()) 
	{
	    //galaxy->readGas(gasFile);
	    cout << "Read gas file: " << gasFile << endl;
	}
	return true;
    }
    return false;
}
